<?php
$username = "w323285_twa";
$password = "xMhbRePE";
$dbname = "d323285_twa";
$host = "md372.wedos.net";